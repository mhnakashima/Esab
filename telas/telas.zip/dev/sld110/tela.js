//VARIAVEIS GLOBAIS ---------------------------------------------------------------

// DEFINE O TEMPO PADRAO DE CARREGAMENTO DAS ANIMACOES EM OBJETOS
var tempo_entrada = 500;
var num_obj = 9

//FUNÇÕES -------------------------------------------------------------------------
// --------------------------------------------------------------------------------
//FUNCAO INICIA EXIBIÇÃO DE OBJETOS DA CAPA  --------------------------------------

function iniciaScript_fc()
{		
	//TOCA AUDIO DA CAPA
 	//toca_audio('audioCapa');
	
	//CRIA EFEITOS DE EXIBIÇÃO NA PÁGINA
	parent.habilitaAvancar();
	
}







